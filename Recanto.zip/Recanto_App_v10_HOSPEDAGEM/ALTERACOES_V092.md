# Recanto v0.9.2 — Arquivos alterados

- `frontend/styles.css`: retirada a camada de fade fixa que cobria os elementos do catálogo e da loja, suavização do limite da rolagem, espaçamento no rodapé da seleção de jogos e classes de assets.
- `frontend/app.js`: removida a introdução da loja; reorganização do modal de jogos; suporte à imagem de cada jogo; novo painel de assets e aplicação de imagens em componentes existentes e novos.
- `frontend/index.html`: atualização da versão para forçar cache novo.
- `frontend/sw.js`: cache atualizado para não reutilizar JavaScript/CSS antigos.
- `backend/game.py`: tabela `ui_assets`, endpoints públicos de leitura e exclusivos do administrador para alteração, suporte a ícones dos jogos nos perfis e na lista de opções.
- `tests/test_v092.py`: testes de segurança, imagens, remoção, perfil e acesso público somente de leitura.
- `ASSETS_GUIA.md`: instruções para usar imagens personalizadas e preservar os arquivos ao atualizar.

**Dados persistentes**: salve cópia do seu `backend/recanto.db`, do `backend/.env` e da pasta `frontend/uploads` antes de atualizar. Não compartilhe o `.env` com terceiros.
