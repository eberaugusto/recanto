@echo off
setlocal
chcp 65001 >nul
cd /d "%~dp0backend"
if not exist ".venv\Scripts\python.exe" (
  echo Execute INSTALAR.bat primeiro.
  pause
  exit /b 1
)
echo ================================================
echo    RECANTO v0.9.1 - SERVIDOR DO APLICATIVO
echo ================================================
echo.
echo PC:      http://localhost:5173
echo Celular: http://IP_DO_SEU_PC:5173
 echo.
echo Para ver seu IPv4, digite ipconfig no Prompt de Comando.
echo Deixe esta janela aberta. Nunca exponha porta 5173 na internet.
echo.
".venv\Scripts\python.exe" -m uvicorn main:app --host 0.0.0.0 --port 5173
pause
