# Configurar login Discord — Recanto v0.8 no PC

Sem perfis fictícios. O login de teste usa sua **conta verdadeira do Discord**, com segurança via OAuth2.

## 1. Criar/configurar seu aplicativo Discord

1. Acesse https://discord.com/developers/applications e entre na sua conta.
2. Clique em **New Application**, ou selecione o aplicativo que criou anteriormente.
3. Em **OAuth2**, copie **Client ID** e **Client Secret**. **Não** envie o Client Secret para outras pessoas.
4. Em **Redirects**, cadastre exatamente:

   `http://localhost:5173/auth/discord/callback`

5. Salve a mudança no portal.

O Recanto solicita `identify` para usar seu Discord ID, nome e avatar. Se configurar a verificação de membros, solicitará também `guilds`. Nenhum bot adicional é necessário para o login.

## 2. Configurar o arquivo local

Na pasta `backend`, abra o arquivo `.env` com Bloco de Notas. Se ele não existir, execute `INSTALAR.bat` uma vez, que o criará a partir de `.env.example`.

Preencha:

```env
APP_ENV=development
ENABLE_DEMO_AUTH=false
DISCORD_CLIENT_ID=SEU_CLIENT_ID
DISCORD_CLIENT_SECRET=SEU_CLIENT_SECRET
DISCORD_REDIRECT_URI=http://localhost:5173/auth/discord/callback
RECANTO_ADMIN_DISCORD_IDS=249610270069096448
```

Mantenha `DATABASE_URL=` e `PUBLIC_BASE_URL=` vazios para testes exclusivamente no PC. `REQUIRED_DISCORD_GUILD_ID=` pode ficar vazio por enquanto ou ser preenchido com o ID do seu servidor para limitar acesso aos membros. Neste caso, seu login Discord autorizará a leitura da lista de servidores.

**Importante:** o Discord vê `localhost` como o navegador do computador que está fazendo login. Por isso, por enquanto teste o login no PC. Acesso pelo celular exigirá configurar uma URL HTTPS própria mais adiante.

## 3. Administradores

A sua conta com Discord ID `249610270069096448` está autorizada como administradora. A permissão é conferida **pelo servidor**, não depende de alterar botões no navegador.

Depois de entrar com essa conta, vá até **Perfil → Gestão do Recanto → Administradores por Discord ID**. Digite outro ID Discord numérico para autorizar alguém ou revogar um ID adicional. O administrador principal só pode ser alterado no `.env` para evitar ser excluído por engano.

Seu ID **não é exibido na tela Configurações** — essa página continua tendo apenas notificações e troca de conta.

## 4. Reiniciar e testar

Feche `INICIAR_RECANTO.bat` se estiver aberto; inicie-o novamente após editar `.env`, acesse http://localhost:5173 e clique em **Login**.

A versão 0.7 não tem botão para escolher Lia, Theo ou Nina. Se a autenticação não funcionar, confira a mensagem exibida na tela e se o Redirect foi salvo exatamente como indicado.
