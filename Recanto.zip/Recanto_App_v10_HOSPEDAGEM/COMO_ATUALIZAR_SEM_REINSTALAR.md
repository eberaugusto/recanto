# Atualizar o Recanto sem reinstalar nos celulares

**Resposta curta: SIM.** O Recanto é um **PWA** instalado a partir do navegador. Ao publicar novos arquivos no servidor HTTPS, a instalação existente continua sendo o mesmo aplicativo e recebe uma atualização automaticamente — sem Play Store e sem novo APK.

## Fluxo de uma atualização futura

1. Faça cópia de segurança do repositório e das informações do banco, especialmente antes de alterar regras de cartas, moedas ou dados persistentes.
2. No PC, abra a pasta **original do repositório GitHub** que está ligada ao Render. **Não crie um repositório novo a cada versão.**
3. Aplique os arquivos atualizados nela: `backend/`, `frontend/` e outros necessários. **NÃO substitua nem envie `backend/.env`, `backend/recanto.db` ou credenciais.** Essas são apenas do PC.
4. Em cada versão, altere a versão do cache em `frontend/sw.js` (`recanto-ui-1.0.0` → `recanto-ui-1.0.1`), e os parâmetros `?v=...` dos arquivos CSS e JS no `frontend/index.html`. Atualize o texto e `/api/version` para refletir a versão.
5. Abra o GitHub Desktop, confira as alterações, crie o **Commit** e clique em **Push origin**.
6. Se Auto-Deploy estiver ligado, o Render publica os arquivos novos automaticamente, depois de construir/iniciar o serviço. O HTTPS **não muda**, e os membros **não reinstalam**.
7. Na próxima abertura, foco ou verificação periódica, o PWA detecta a nova versão do Service Worker e apresenta **“✨ Nova versão do Recanto disponível” → “Atualizar”**. O usuário toca no botão e o app recarrega com os novos arquivos. Existe também **Configurações → Verificar atualizações**.

## O que se mantém após atualizar?

- **Contas e login Discord:** persistem via banco Neon (a sessão continua, salvo se você invalidá-la ou expirar).
- **Moedas, cards, packs fechados, pets, selos, trocas e missões:** persistem no banco Neon. Atualizar arquivos Python/HTML/CSS/JS não apaga os registros.
- **Ícones e capas enviados pela Central de Assets:** persistem no Cloudinary, com os endereços salvos na Neon.
- **Instalação na tela inicial:** mantém o mesmo ícone e atalho. Não exige novo arquivo instalado.

## Observações para evitar problemas

- O botão de atualização **não publica novas versões**: ele aplica uma versão que você já publicou no Render. Quem publica é o dono do repositório GitHub.
- O app não força um reload no meio da abertura de cards nem durante uma proposta de troca: ele oferece o botão para atualizar quando o usuário quiser.
- Se o celular estiver sem conexão, continuará dependendo dos arquivos que já possui e só buscará novidades quando conseguir se conectar. A lógica online de jogo continua exigindo internet.
- Se mudar o domínio, o PWA instalado e o login Discord podem precisar de reconfiguração ou nova instalação. **Mantenha o mesmo endereço HTTPS.**
- Atualizações destrutivas de estrutura de banco não devem ser feitas apenas copiando arquivos. Faça migrações controladas, com backup e teste antes da publicação.
- Em modo privado/incógnito o PWA pode não estar disponível; teste no navegador normal.

**Resumo:** você envia uma nova versão pelo GitHub Desktop → Render publica → usuários abrem o Recanto e clicam em **Atualizar** dentro do app → pronto. Dados permanecem no banco e no armazenamento externo.
