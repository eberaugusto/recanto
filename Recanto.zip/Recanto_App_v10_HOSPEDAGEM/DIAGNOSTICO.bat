@echo off
setlocal
chcp 65001 >nul
cd /d "%~dp0"
if not exist "backend\.venv\Scripts\python.exe" (
  echo Execute INSTALAR.bat primeiro.
  pause
  exit /b 1
)
"backend\.venv\Scripts\python.exe" -c "import urllib.request; u='http://127.0.0.1:5173'; checks=['/','/app.js','/styles.css','/api/health','/api/config','/icons/icon-192.png']; [(lambda r: print(str(r.status)+'  '+p+'  '+r.headers.get('Content-Type','')))(urllib.request.urlopen(u+p, timeout=4)) for p in checks]"
if errorlevel 1 echo Algum teste falhou. Verifique se INICIAR_RECANTO.bat esta aberto.
pause
