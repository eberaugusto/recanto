# Como testar uma Pequena Lenda 3D do Khada no Recanto

1. Abra o Khada em https://modelviewer.lol/ e encontre uma **Pequena Lenda** desejada. O Khada trabalha com modelos 3D e animações de League of Legends.
2. Selecione a opção de exportação apropriada, quando disponível. Para este Recanto, escolha **glTF 2.0**, em `.glb` ou `.gltf`. Se o Khada entregar outro formato, será necessário convertê-lo antes de cadastrar.
3. Se baixar **`.glb`**, selecione o arquivo sozinho no upload 3D da Gestão. Se baixar **`.gltf`**, selecione ao mesmo tempo o `.gltf`, eventuais `.bin` e suas texturas. O upload exige arquivos no mesmo diretório e referências relativas simples, sem subpastas.
4. Consulte quais **animações** estão embutidas na exportação. Digite o **nome exato** nos campos opcionais `idle`, `carinho`, `alimentação` e `veterinário`. Não presuma que uma ação como “comer” exista no modelo. Se não existir, deixe o campo vazio.
5. Em **Gestão do Recanto → Cadastrar Pequena Lenda**, preencha nome, emoji/imagem, selecione os arquivos, informe as animações e salve.
6. Vá para **Pet** e adote sua Pequena Lenda. O modelo deve surgir no cartão, e você poderá girá-lo com o mouse. Quando clicar em Alimentar ou Acariciar, o app tentará reproduzir a animação configurada e fará um efeito de reação.

**Caso veja apenas a imagem/emoji:** a interface continua funcional. Confirme conexão à internet para obter a biblioteca 3D, erros do navegador com F12 → Console e se o arquivo glTF realmente contém malhas/texturas compatíveis. Modelos grandes podem prejudicar a fluidez, então prefira versões otimizadas.

**Limite atual:** o visualizador usa `@google/model-viewer` 4.1.0, carregado de CDN **somente ao acessar um pet com modelo 3D**, o que evita peso nas demais abas. Sem CDN acessível, haverá fallback 2D. O sistema ainda não inclui edição de animações ou conversão de modelos; ele reproduz clipes exportados previamente.

**Direitos de uso:** Khada e a Riot têm condições próprias para modelos, artes e recursos. Verifique autorização antes de redistribuir recursos de League of Legends para terceiros.
