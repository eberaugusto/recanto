# Publicar o Recanto na internet — v1.0

**Objetivo:** permitir login Discord e instalação PWA no Android/iPhone, com uma única URL HTTPS pública. **Não precisa publicar na Play Store ou App Store.**

A primeira publicação exigirá contas nos serviços abaixo e a configuração de alguns valores secretos. O pacote foi preparado, mas NÃO está publicado: esse processo depende das suas contas. **Não compartilhe Client Secret, URL do banco com senha ou Cloudinary API Secret.**

## Arquitetura

- **GitHub (repositório PRIVADO):** guarda o código, histórico de versões e configurações sem segredos.
- **Render (Web Service Free):** executa `backend.main:app` em Python 3.12 e disponibiliza uma URL `https://SEU-NOME.onrender.com`. O HTTPS é gerenciado pelo Render.
- **Neon (PostgreSQL Free):** guarda usuários, sessões, moedas, cards, packs, pets, missões e opções personalizadas permanentemente. Nunca usar SQLite no plano gratuito do Render.
- **Cloudinary (opcional, Free):** recebe PNG/JPG/WEBP por upload pela Central de Assets; o servidor envia com credenciais privadas. Sem Cloudinary, o admin pode cadastrar **URLs HTTPS persistentes**, mas não enviar arquivo diretamente pela Central.
- **Discord Developer Portal:** autoriza o login. O aplicativo usa OAuth2; não precisa criar bot.

> O Render Free hiberna após cerca de 15 minutos sem requisições e o primeiro acesso após isso pode levar ~1 minuto. Os dados permanecem na Neon. Render Free não oferece armazenamento local persistente; scripts que escrevem `/uploads` ou SQLite locais NÃO preservam dados após deploy/hibernação.

## 1 — Criar banco na Neon

1. Acesse https://console.neon.tech e crie a conta gratuita.
2. Crie um projeto PostgreSQL chamado **Recanto**, escolha uma região disponível (idealmente próxima dos usuários/Render).
3. Vá em **Connect** e escolha a string de conexão para seu banco, idealmente com SSL habilitado. Salve-a num lugar privado.
4. Exemplo fictício: `postgresql://usuario:SENHA@ep-exemplo.neon.tech/neondb?sslmode=require`. **Nunca compartilhe sua string verdadeira.**
5. Esta URL será o valor de `DATABASE_URL` no Render. O Recanto cria as tabelas automaticamente ao iniciar, inclusive as regras do jogo.

**Atenção:** o banco hospedado começará vazio (com os cards e pets padrão). O `backend/recanto.db` da sua instalação local é SQLite e **não será transferido automaticamente**. Não publique o `.db` no GitHub. Se quiser preservar o progresso local, faça backup e planeje uma migração de dados antes de permitir novas ações no site.

## 2 — Colocar o projeto num repositório GitHub privado

1. Instale o **GitHub Desktop**: https://desktop.github.com.
2. Extraia `Recanto_App_v10_HOSPEDAGEM.zip` no PC.
3. No GitHub Desktop, crie um repositório **a partir da pasta extraída** (File → Add local repository → Create a repository here, ou File → New repository usando essa pasta).
4. Nome sugerido: `recanto-app`. Use a pasta do projeto como **raiz do repositório**: a raiz deve conter `render.yaml`, `backend/`, `frontend/` e `tests/`.
5. Em **Publish repository**, marque **Keep this code private**.
6. Confira a lista de arquivos antes de publicar. Jamais envie `backend/.env`, `backend/recanto.db`, pastas `.venv`, credenciais ou exports de banco. O `.gitignore` foi configurado para ignorá-los.
7. Faça seu primeiro commit e publique no GitHub.

## 3 — Criar o Web Service gratuito no Render

1. Acesse https://dashboard.render.com e conecte sua conta GitHub.
2. Clique **New → Web Service** (não use Static Site: o Recanto inclui backend Python).
3. Selecione o repositório privado `recanto-app` e o branch `main`.
4. Escolha **Python** e o plano **Free**. Configure:

| Campo Render | Valor |
|---|---|
| Root Directory | vazio / raiz do repositório |
| Build Command | `pip install -r backend/requirements.txt` |
| Start Command | `uvicorn backend.main:app --host 0.0.0.0 --port $PORT --proxy-headers` |
| Health Check Path | `/api/health` |
| Auto-Deploy | `On Commit` (ou `After CI Checks Pass`) |

O pacote também contém `render.yaml` com esses valores, para a opção **Blueprint** caso prefira. Não crie dois serviços para o mesmo Recanto.

5. Escolha o nome do serviço, por exemplo `recanto-comunidade`. O Render mostrará seu endereço real, como `https://recanto-comunidade.onrender.com` **se o nome estiver disponível**.
6. Antes do deploy funcionar, cadastre as variáveis **Environment** a seguir. Não coloque esses valores dentro do GitHub:

| Variável | Exemplo / conteúdo |
|---|---|
| `APP_ENV` | `production` |
| `DATABASE_URL` | URL privada **real** da Neon |
| `PUBLIC_BASE_URL` | `https://SEU-NOME.onrender.com` (URL exata fornecida pelo Render, sem `/` final) |
| `DISCORD_CLIENT_ID` | Client ID do aplicativo Discord Recanto |
| `DISCORD_CLIENT_SECRET` | Client Secret do mesmo aplicativo Discord |
| `DISCORD_REDIRECT_URI` | `https://SEU-NOME.onrender.com/auth/discord/callback` |
| `RECANTO_ADMIN_DISCORD_IDS` | `249610270069096448` |
| `REQUIRED_DISCORD_GUILD_ID` | opcional: ID do servidor se quiser restringir o acesso somente a membros |
| `CLOUDINARY_CLOUD_NAME` | opcional: nome do cloud para uploads de imagens |
| `CLOUDINARY_API_KEY` | opcional: API Key |
| `CLOUDINARY_API_SECRET` | opcional: API Secret (NUNCA compartilhe) |

> Se optar por um Blueprint, `sync: false` significa que você precisará inserir os valores secretamente na criação/edição do serviço. Se não souber ainda seu domínio, crie o serviço, copie a URL atribuída e edite as variáveis antes de concluir um novo deploy.

7. Clique em **Deploy**. Verifique nos **Logs** se o banco conectou e as rotas iniciaram. Quando estiver pronto, `https://SEU-NOME.onrender.com/api/health` deve responder JSON `status: ok`.

**Não desative o HTTPS** e **não abra a porta 5173 do PC na internet**: com Render, não se usa IP residencial, Radmin nem regras locais de firewall.

## 4 — Corrigir o retorno do Discord (essencial)

1. Acesse https://discord.com/developers/applications e selecione o mesmo aplicativo Discord utilizado localmente.
2. Em **OAuth2 → Redirects**, adicione `https://SEU-NOME.onrender.com/auth/discord/callback` exatamente, substituindo pelo endereço real do Render.
3. Salve em **Save Changes**.
4. Compare cuidadosamente com `DISCORD_REDIRECT_URI` no Render — protocolo `https`, nome do domínio, caminho e barras precisam corresponder **exatamente**.
5. Use o **Client ID** e o **Client Secret** desse mesmo aplicativo na hospedagem. O Client Secret nunca deve aparecer no frontend.
6. Se adicionar `REQUIRED_DISCORD_GUILD_ID`, o aplicativo também pedirá acesso à lista de servidores e recusará contas não autorizadas. O servidor não precisa de um bot do Recanto.
7. Abra o endereço HTTPS no seu PC e no celular e faça login. O retorno deve ser a própria URL HTTPS, não `localhost`.

## 5 — Armazenamento de capas e ícones (recomendado)

1. Crie uma conta gratuita em https://cloudinary.com e abra o painel.
2. Copie `Cloud Name`, `API Key`, `API Secret` e preencha as três variáveis `CLOUDINARY_*` no Render (em Environment).
3. Salve/reinicie o serviço. Entre com seu Discord de administrador e abra **Gestão do Recanto → Central de Assets**.
4. Envie uma arte PNG/JPG/WEBP de até 4 MB e cadastre-a. O backend valida a imagem e envia ao Cloudinary com assinatura privada, retornando um endereço HTTPS persistente, salvo na Neon.
5. Você também pode continuar cadastrando URLs HTTPS de imagens externas sem usar Cloudinary.

**Atenção a artes locais antigas:** links como `/uploads/123.png` usados na versão local não ficam automaticamente persistentes no Render. Reenvie esses arquivos pela versão hospedada ou substitua suas URLs por imagens hospedadas. **Modelos 3D**: o upload de modelos `.glb/.gltf` continua apenas no PC, porque modelos glTF e texturas precisam ficar num armazenamento público persistente. Para publicar um GLB já cadastrado, coloque seus arquivos numa pasta versionada em `frontend/models/<identificador-32-hex>/<arquivo.glb>` dentro do repositório ou utilize uma URL HTTPS com CORS válido. Não use `/models` gerado somente no disco efêmero do Render.

## 6 — Instalar como aplicativo no celular

- **Android/Chrome**: abra `https://SEU-NOME.onrender.com` → menu ⋮ → **Instalar app** (ou **Adicionar à tela inicial**). O botão **Instalar app** da tela inicial do Recanto aparece quando o Chrome emite o convite nativo de instalação.
- **iPhone/Safari**: abra o endereço HTTPS → Compartilhar → **Adicionar à Tela de Início** → **Abrir como App da Web** (se oferecido). A instalação por botão automático pode não aparecer no Safari.
- Depois, entre com Discord no PWA instalado. O servidor de todos os membros é o MESMO, por isso os inventários e as trocas são compartilhados corretamente.

## 7 — Teste antes de convidar a comunidade

1. Acesse `/api/health` no HTTPS e confira a resposta.
2. Faça login Discord com o administrador `249610270069096448`.
3. Confirme se o botão Gestão do Recanto aparece e se outra conta NÃO consegue administrar.
4. Teste a carteira, resgate diário, compra/abertura do pacote, inventário e logout.
5. Teste imagens enviadas pela Central e depois faça um novo deploy para conferir persistência.
6. Instale o PWA num Android, feche e abra novamente; valide o login e o fluxo Discord HTTPS.
7. Faça um backup/export do banco periodicamente. O plano Free não substitui uma política própria de backup.

## Limitações da hospedagem gratuita

- **Render Free:** hiberna após 15 minutos de inatividade, primeira carga pode demorar até ~1 minuto e tem limites de uso; seu disco é efêmero.
- **Neon Free:** tem limites de armazenamento e computação (no momento da preparação do pacote, até 1 GB de banco por projeto, sujeitos à política atual).
- **Cloudinary Free:** tem franquia mensal de créditos e não serve para armazenamento ilimitado.
- **Notificações push automáticas:** o app já solicita permissão e tem a estrutura básica do Service Worker, mas ainda NÃO há servidor de envio e agendamento implementado.

Essa combinação é ótima para **teste com uma comunidade pequena**, mas não garante disponibilidade permanente 24/7. Para operação mais intensa, será necessário rever limites ou contratar hospedagem.
