@echo off
setlocal
chcp 65001 >nul
cd /d "%~dp0"
echo ============================================
echo        RECANTO v0.7 - INSTALACAO
echo ============================================
py -3.12 --version >nul 2>&1
if errorlevel 1 (
  echo ERRO: Python 3.12 nao encontrado. Instale Python 3.12.
  pause
  exit /b 1
)
if not exist "backend\.env" copy "backend\.env.example" "backend\.env" >nul
if not exist "backend\.venv\Scripts\python.exe" (
  echo Criando ambiente Python 3.12...
  py -3.12 -m venv "backend\.venv"
  if errorlevel 1 goto erro
)
echo Instalando dependencias Python...
"backend\.venv\Scripts\python.exe" -m pip install --disable-pip-version-check -r "backend\requirements.txt"
if errorlevel 1 goto erro
echo INSTALADO! Execute INICIAR_RECANTO.bat.
pause
exit /b 0
:erro
echo FALHA NA INSTALACAO. Leia as mensagens acima.
pause
exit /b 1
