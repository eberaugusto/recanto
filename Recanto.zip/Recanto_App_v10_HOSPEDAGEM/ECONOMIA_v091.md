# Economia inicial — Recanto v0.9.1

Os números abaixo são **valores iniciais de teste**, não preços definitivos. O objetivo é fazer com que as cartas e a moeda tenham valor no médio prazo, evitando recompensas excessivas e compras imediatas de packs todos os dias.

## Chances de raridade

| Fonte | Comum | Raro | Lendário | Prismático |
|---|---:|---:|---:|---:|
| Resgate a cada 5 horas | 60% | 29% | 10% | 1% |
| Pack 3 cards (foco em Lendário/Prismático) | 65% | 20% | 12% | 3% |
| Pack 5 cards (quantidade) | 65% | 25% | 9% | 1% |
| Expedição do pet, se encontrar card | 84% | 14% | 1,8% | 0,2% |

O sorteio considera apenas os tiers que ainda têm cópias globais disponíveis, então o resultado observado pode variar por falta de estoque. Os packs reservam exemplares no momento da compra. Os bônus de moedas são creditados quando o card é recebido: no resgate ou na abertura do pacote, não na compra. As probabilidades por pack somam 100% e são aplicadas por card.

## Loja e recompensas

| Evento / compra | Moedas |
|---|---:|
| Resgate diário de moedas | +35 |
| Card Comum obtido (diário, pacote ou expedição) | +1 |
| Card Raro obtido (diário, pacote ou expedição) | +2 |
| Card Lendário obtido (diário, pacote ou expedição) | +4 |
| Card Prismático obtido (diário, pacote ou expedição) | +5 |
| Pack de 3 cards (maior chance de Lendário/Prismático) | 700 |
| Pack de 5 cards (maior quantidade) | 550 |
| 3 biscoitos | 65 |
| Frutinha | 45 |
| Banquete | 90 |
| Troca concluída (cada um; até 2 vezes por dia) | +8 |
| Visitante acaricia o pet de outro membro, uma vez por dia por pet | +3 |
| Visitante alimenta o pet de outro, com petisco, uma vez por dia por pet | +5 |
| Dono do pet recebe por visita válida | +1 |
| Veterinário: resgate do pet | 180 |

## Ofertas e vendas de cópias

| Tier | Oferta mínima por uma carta | Venda ao sistema de uma cópia extra |
|---|---:|---:|
| Comum | 35 | 10 |
| Raro | 110 | 40 |
| Lendário | 350 | 120 |
| Prismático | 850 | 300 |

**Regras:** a proposta em moedas reserva o dinheiro do comprador imediatamente. Aceitar transfere o card e paga o vendedor. Recusar ou cancelar devolve o saldo. Ofertas concorrentes pela mesma cópia são reembolsadas quando uma é aceita. A venda para o sistema exige que você tenha pelo menos duas cópias do mesmo card e preserva a última cópia.

Os mínimos e as vendas são regras fixas desta primeira configuração; os demais parâmetros principais (recompensas gerais, preços da loja e veterinário) continuam editáveis em Gestão do Recanto. Alterações futuras de mínimos e valores de venda exigem atualizar essas tabelas no código.

## Expedições da Pequena Lenda

| Missão | Duração | Fome perdida ao voltar | Moedas recebidas | Chance de achar card |
|---|---|---:|---:|---:|
| Passeio no bosque | 1h | 12 | 12–22 | 2% |
| Exploração das ruínas | 3h | 28 | 30–50 | 5% |
| Jornada distante | 8h | 45 | 62–90 | 8% |

Ao iniciar, o pet fica indisponível para alimento e carinho, inclusive de visitantes. Após o prazo, o jogador usa **Receber recompensas** para concluir a expedição; é nessa operação que as moedas e o possível card são entregues uma única vez. Não é possível enviar duas expedições simultâneas. Para começar, o pet precisa ter a fome suficiente para a missão, mais uma margem de segurança de 15 pontos.

## Recompensas de missões (uma vez por dia, conforme o objetivo)

- Resgatar card: 12 moedas.
- Resgatar moedas: 8 moedas.
- Concluir troca: 30 moedas.
- Acariciar pet: 8 moedas.
- Alimentar pet: 12 moedas.
- Adotar pet: 20 moedas (objetivo eventual).
- Abrir pacote: 15 moedas.

**Recomendação:** mantenha esses valores na fase de testes até termos dados reais de quantidade de membros, aquisições e saldos. O estoque de cards continua limitado globalmente a 3/2/1/1 cópias por título conforme o tier.

## Migração dos preços e bônus para a v0.9.1

O banco existente é preservado. Os preços que ainda estiverem com os valores padrão da v0.9 (**850/600**) são atualizados para **700/550**; preços personalizados com outros valores não são sobrescritos. O antigo bônus fixo é substituído pelas quatro configurações `card_bonus_comum`, `card_bonus_raro`, `card_bonus_lendário` e `card_bonus_prismático`, disponíveis na Gestão.
