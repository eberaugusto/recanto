# Central de Assets — Recanto v0.9.2

Acesse **Perfil → Gestão do Recanto → 🖼️ Central de Assets** com uma conta autorizada por Discord ID.

## Ícones dos 20 jogos

1. Em **Elemento a personalizar**, escolha **Jogo · League of Legends**, por exemplo.
2. Selecione um PNG, JPG ou WEBP do seu computador (até 4 MB) ou cole uma URL HTTPS.
3. Clique em **Salvar imagem**.
4. O ícone personalizado substitui o emoji na seleção de jogos, no seu Perfil e nos perfis públicos.
5. Repita para outros jogos. Para voltar ao emoji, selecione o jogo e use **Remover imagem do elemento**.

As imagens dos jogos são opcionais. Ao não definir uma imagem, os ícones ilustrativos continuam aparecendo.

## Fundos, botões e outros elementos

Escolha uma opção na lista como **Logo na tela de login**, **Fundo geral do aplicativo**, **Ícone Loja**, **Ícone Perfil**, **Ícone de moedas** etc. Envie um arquivo e salve. O aplicativo não altera os cliques nem a lógica desses elementos.

Para personalizar outro elemento, preencha **Chave personalizada** com um identificador sem espaços, por exemplo `capa-pack3`, e **Seletor CSS** com o elemento desejado:

| Elemento | Seletor CSS | Modo |
|---|---|---|
| Capa do pack de 3 | `#shop-pack3 .product-cover` | Imagem de fundo |
| Capa do pack de 5 | `#shop-pack5 .product-cover` | Imagem de fundo |
| Total de moedas da loja | `#shopWallet` | Imagem de fundo |
| Tela de pet | `#petScreen` | Imagem de fundo |
| Painel de Selos | `.profile-badges` | Imagem de fundo |
| Cartões de missão | `.mission-cover` | Imagem de fundo |
| Botão de config. | `#settings` | Ícone sobre o elemento |

Prefira **Fundo** para containers e **Ícone** para botões. **Imagem (tag img)** serve para substituir a origem de um elemento `<img>`, como a logo. O seletor deve existir na página para que a imagem apareça. Se um recurso for recriado ao mudar de aba, a imagem será reaplicada.

**Se a função principal do elemento for uma imagem**, como card, pet, banner de coleção, capa de produto ou missão, o Recanto também mantém seus campos próprios de cadastro. Use esses campos para imagens individuais e a Central para personalizar a aparência global do app.

## Onde ficam os arquivos

As imagens enviadas no PC são salvas em `frontend/uploads/`, com nomes aleatórios. Seus vínculos com elementos e jogos são guardados no banco `backend/recanto.db`.

**Para atualizar de versão sem perder imagens**, copie tanto o arquivo `.db` quanto toda a pasta `frontend/uploads` (além do `backend/.env`). Faça backup antes de copiar. Não é necessário substituir o diretório `frontend/icons` de outra versão.

No ambiente de hospedagem gratuito com armazenamento temporário, upload local não é durável; quando chegar a publicação HTTPS, será preciso guardar as imagens em armazenamento persistente ou usar URLs HTTPS estáveis. O painel já aceita URLs HTTPS.

As imagens de marcas/jogos precisam ser utilizadas de acordo com as respectivas regras de uso e direitos dos titulares.
